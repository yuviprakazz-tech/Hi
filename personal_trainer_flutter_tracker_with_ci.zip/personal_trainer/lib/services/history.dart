import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

class ExerciseLog {
  final String name;
  final int sets;
  final int reps; // total reps (or seconds for holds)
  final int durationSec; // time spent on this exercise

  const ExerciseLog({required this.name, required this.sets, required this.reps, required this.durationSec});

  Map<String, dynamic> toJson() => {
    'name': name,
    'sets': sets,
    'reps': reps,
    'durationSec': durationSec,
  };

  factory ExerciseLog.fromJson(Map<String, dynamic> j) => ExerciseLog(
    name: j['name'] ?? '',
    sets: j['sets'] ?? 0,
    reps: j['reps'] ?? 0,
    durationSec: j['durationSec'] ?? 0,
  );
}

class SessionLog {
  final String title;
  final DateTime startedAt;
  final int totalDurationSec;
  final List<ExerciseLog> items;

  const SessionLog({required this.title, required this.startedAt, required this.totalDurationSec, required this.items});

  Map<String, dynamic> toJson() => {
    'title': title,
    'startedAt': startedAt.toIso8601String(),
    'totalDurationSec': totalDurationSec,
    'items': items.map((e) => e.toJson()).toList(),
  };

  factory SessionLog.fromJson(Map<String, dynamic> j) => SessionLog(
    title: j['title'] ?? '',
    startedAt: DateTime.tryParse(j['startedAt'] ?? '') ?? DateTime.now(),
    totalDurationSec: j['totalDurationSec'] ?? 0,
    items: ((j['items'] ?? []) as List).map((e) => ExerciseLog.fromJson(e)).toList(),
  );
}

class HistoryStore {
  static const _k = 'history_v1';

  static Future<void> add(SessionLog s) async {
    final prefs = await SharedPreferences.getInstance();
    final all = await load();
    all.insert(0, s);
    await prefs.setString(_k, jsonEncode(all.map((e) => e.toJson()).toList()));
  }

  static Future<List<SessionLog>> load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_k);
    if (raw == null) return [];
    final list = (jsonDecode(raw) as List).cast<Map<String, dynamic>>();
    return list.map((m) => SessionLog.fromJson(m)).toList();
  }

  static Future<void> clear() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_k);
  }
}
