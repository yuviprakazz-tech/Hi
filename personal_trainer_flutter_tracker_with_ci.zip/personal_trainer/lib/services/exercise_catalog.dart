import '../models/exercise.dart';

class ExerciseCatalog {
  static final Map<String, Exercise> all = {
    'warmup_walk': Exercise(
      key: 'warmup_walk',
      name: 'Warm-up Walk',
      image: 'assets/images/warmup_walk.png',
      tips: [
        'Walk at a pace that slightly raises your heart rate.',
        'Use a 1–2% incline if on treadmill.',
        'Maintain tall posture and relaxed shoulders.'
      ],
      type: 'cardio',
    ),
    'elliptical': Exercise(
      key: 'elliptical',
      name: 'Elliptical',
      image: 'assets/images/elliptical.png',
      tips: [
        'Keep cadence smooth; avoid bouncing.',
        'RPE 5–6: conversational but working.',
        'Light grip on handles, core engaged.'
      ],
      type: 'cardio',
    ),
    'cycling': Exercise(
      key: 'cycling',
      name: 'Cycling (Stationary)',
      image: 'assets/images/cycling.png',
      tips: [
        'Seat height: slight knee bend at bottom.',
        'Spin smoothly; avoid rocking hips.',
        'Keep RPE around target zone.'
      ],
      type: 'cardio',
    ),
    'goblet_squat': Exercise(
      key: 'goblet_squat',
      name: 'Goblet Squat',
      image: 'assets/images/goblet_squat.png',
      tips: [
        'Feet shoulder-width; brace core.',
        'Sit down between hips; keep chest tall.',
        'Knees track over toes; full foot on floor.'
      ],
      type: 'strength',
    ),
    'leg_press': Exercise(
      key: 'leg_press',
      name: 'Leg Press',
      image: 'assets/images/leg_press.png',
      tips: [
        'Lower until thighs ~parallel without pelvis tilting.',
        'Do not lock knees at the top.',
        'Push through mid-foot.'
      ],
      type: 'strength',
    ),
    'chest_press': Exercise(
      key: 'chest_press',
      name: 'Machine Chest Press',
      image: 'assets/images/chest_press.png',
      tips: [
        'Shoulder blades back & down.',
        'Wrists neutral; control the eccentric.',
        'Exhale as you press.'
      ],
      type: 'strength',
    ),
    'seated_row': Exercise(
      key: 'seated_row',
      name: 'Seated Cable Row',
      image: 'assets/images/seated_row.png',
      tips: [
        'Neutral spine; avoid leaning too far back.',
        'Pull elbows toward hips.',
        'Squeeze shoulder blades together.'
      ],
      type: 'strength',
    ),
    'db_shoulder_press': Exercise(
      key: 'db_shoulder_press',
      name: 'Seated DB Shoulder Press',
      image: 'assets/images/db_shoulder_press.png',
      tips: [
        'Brace core; avoid arching lower back.',
        'Press slightly in front of body line.',
        'Control down phase.'
      ],
      type: 'strength',
    ),
    'plank': Exercise(
      key: 'plank',
      name: 'Plank',
      image: 'assets/images/plank.png',
      tips: [
        'Elbows under shoulders; ribs down.',
        'Glutes and quads lightly engaged.',
        'Breathe steadily.'
      ],
      type: 'strength',
    ),
    'bench_press': Exercise(
      key: 'bench_press',
      name: 'Bench Press',
      image: 'assets/images/bench_press.png',
      tips: [
        'Feet planted; shoulder blades retracted.',
        'Bar to mid-chest; forearms vertical.',
        'No bounce on chest.'
      ],
      type: 'strength',
    ),
    'pulldown': Exercise(
      key: 'pulldown',
      name: 'Lat Pulldown',
      image: 'assets/images/pulldown.png',
      tips: [
        'Slight lean back, chest up.',
        'Pull bar to upper chest; elbows down.',
        'Control return; avoid momentum.'
      ],
      type: 'strength',
    ),
    'overhead_press': Exercise(
      key: 'overhead_press',
      name: 'Overhead Press',
      image: 'assets/images/overhead_press.png',
      tips: [
        'Squeeze glutes; ribs down.',
        'Press bar/dumbbells overhead in straight path.',
        'Head moves slightly back then through.'
      ],
      type: 'strength',
    ),
    'row': Exercise(
      key: 'row',
      name: 'Row (Machine/Chest Supported)',
      image: 'assets/images/row.png',
      tips: [
        'Neutral spine; drive elbows back.',
        'Squeeze shoulder blades.',
        'Avoid shrugging.'
      ],
      type: 'strength',
    ),
    'rdl': Exercise(
      key: 'rdl',
      name: 'Romanian Deadlift',
      image: 'assets/images/rdl.png',
      tips: [
        'Hinge at hips; slight knee bend.',
        'Keep bar close; neutral spine.',
        'Feel hamstring stretch; stand tall.'
      ],
      type: 'strength',
    ),
    'knee_raise': Exercise(
      key: 'knee_raise',
      name: 'Hanging Knee Raise',
      image: 'assets/images/knee_raise.png',
      tips: [
        'Posterior tilt; avoid swinging.',
        'Exhale as knees rise.',
        'Control down slowly.'
      ],
      type: 'strength',
    ),
    'leg_curl': Exercise(
      key: 'leg_curl',
      name: 'Leg Curl',
      image: 'assets/images/leg_curl.png',
      tips: [
        'Pad above heels; hips down.',
        'Full control through range.',
        'Avoid cramping by not rushing.'
      ],
      type: 'strength',
    ),
    'leg_extension': Exercise(
      key: 'leg_extension',
      name: 'Leg Extension',
      image: 'assets/images/leg_extension.png',
      tips: [
        'Align knees with machine pivot.',
        'Stop short of lockout if knees sensitive.',
        'Control eccentric.'
      ],
      type: 'strength',
    ),
    'calf_raise': Exercise(
      key: 'calf_raise',
      name: 'Calf Raise',
      image: 'assets/images/calf_raise.png',
      tips: [
        'Full stretch at bottom.',
        'Pause at the top.',
        'Keep reps smooth.'
      ],
      type: 'strength',
    ),
    'bird_dog': Exercise(
      key: 'bird_dog',
      name: 'Bird Dog',
      image: 'assets/images/bird_dog.png',
      tips: [
        'Hands under shoulders; knees under hips.',
        'Reach opposite arm/leg; keep hips level.',
        'Focus on control, not height.'
      ],
      type: 'strength',
    ),
    'hamstring_stretch': Exercise(
      key: 'hamstring_stretch',
      name: 'Hamstring Stretch',
      image: 'assets/images/hamstring_stretch.png',
      tips: [
        'Hinge at hips keeping back neutral.',
        'Gentle tension, no pain.',
        'Hold 20–30s, breathe.'
      ],
      type: 'stretch',
    ),
    'chest_stretch': Exercise(
      key: 'chest_stretch',
      name: 'Chest Stretch',
      image: 'assets/images/chest_stretch.png',
      tips: [
        'Use doorway/wall; elbow at 90°.',
        'Turn torso away until mild stretch.',
        'Hold 20–30s, breathe.'
      ],
      type: 'stretch',
    ),
  };

  // Basic keyword resolver from a free-text line in the plan
  static Exercise resolve(String line) {
    final l = line.toLowerCase();
    String key = 'warmup_walk';
    if (l.contains('elliptical')) key = 'elliptical';
    else if (l.contains('cycling') or l.contains('bike')) key = 'cycling';
    else if (l.contains('goblet squat')) key = 'goblet_squat';
    else if (l.contains('leg press')) key = 'leg_press';
    else if (l.contains('machine chest press') or l.contains('chest press')) key = 'chest_press';
    else if (l.contains('seated row') or l.contains('row')) key = 'row';
    else if (l.contains('lat pulldown') or l.contains('pulldown')) key = 'pulldown';
    else if (l.contains('overhead press')) key = 'overhead_press';
    else if (l.contains('db shoulder press')) key = 'db_shoulder_press';
    else if (l.contains('plank')) key = 'plank';
    else if (l.contains('romanian')) key = 'rdl';
    else if (l.contains('leg curl')) key = 'leg_curl';
    else if (l.contains('leg extension')) key = 'leg_extension';
    else if (l.contains('calf raise')) key = 'calf_raise';
    else if (l.contains('bird-dog') or l.contains('bird dog')) key = 'bird_dog';
    else if (l.contains('bench press')) key = 'bench_press';
    else if (l.contains('warm-up') or l.contains('warmup')) key = 'warmup_walk';
    else if (l.contains('stretch') and l.contains('hamstring')) key = 'hamstring_stretch';
    else if (l.contains('stretch') and l.contains('chest')) key = 'chest_stretch';
    return all[key]!;
  }
}
