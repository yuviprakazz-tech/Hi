import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/user_profile.dart';
import '../models/workout.dart';

class Storage {
  static const _profileKey = 'profile_v1';
  static const _planKey = 'plan_v1';

  static Future<UserProfile?> loadProfile() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_profileKey);
    if (raw == null) return null;
    return UserProfile.fromJson(jsonDecode(raw));
    }

  static Future<void> saveProfile(UserProfile p) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_profileKey, jsonEncode(p.toJson()));
  }

  static Future<void> savePlan(List<Workout> plan) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
        _planKey, jsonEncode(plan.map((e) => e.toJson()).toList()));
  }

  static Future<List<Workout>> loadPlan() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_planKey);
    if (raw == null) return [];
    final list = (jsonDecode(raw) as List).cast<Map<String, dynamic>>();
    return list.map((m) => Workout.fromJson(m)).toList();
  }
}
