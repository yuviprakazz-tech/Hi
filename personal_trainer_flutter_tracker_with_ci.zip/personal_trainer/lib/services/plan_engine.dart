import '../models/user_profile.dart';
import '../models/workout.dart';

class PlanEngine {
  // Very simple rules-based engine (not medical advice).
  static List<Workout> buildPlan(UserProfile p) {
    final bool isBeginner = p.experienceLevel == 0;
    final bool highBMI = p.bmi >= 30.0;
    final bool hasBackPain = p.conditions.map((e) => e.toLowerCase()).contains('back_pain');
    final bool hasHypertension = p.conditions.map((e) => e.toLowerCase()).contains('hypertension');

    final int days = p.daysPerWeek.clamp(2, 6);

    List<Workout> plan = [];

    for (int d = 1; d <= days; d++) {
      String focus;
      if (days <= 3) {
        focus = 'full_body';
      } else {
        focus = (d % 2 == 0) ? 'upper' : 'lower';
      }

      final List<String> ex = [];

      // Warm-up
      ex.add('Warm-up: 8–12 min brisk walk or cycling (RPE 4)');

      // Cardio first for weight management / adherence
      if (highBMI || hasHypertension) {
        ex.add('Cardio: 12–20 min elliptical or cycling (RPE 5–6)');
      } else {
        ex.add('Cardio: 8–12 min treadmill walk (incline 2–4%)');
      }

      // Resistance training (machine-dominant for safety if beginner)
      if (focus == 'full_body') {
        ex.addAll(_fullBodyBlock(isBeginner, hasBackPain));
      } else if (focus == 'upper') {
        ex.addAll(_upperBlock(isBeginner));
      } else {
        ex.addAll(_lowerBlock(isBeginner, hasBackPain));
      }

      // Cooldown
      ex.add('Cooldown & mobility: 5–8 min (hamstrings, hip flexors, chest)');
      String note = 'Keep RPE around 6 (comfortable hard). Rest 60–90s between sets.';
      if (hasHypertension) {
        note += ' Avoid breath-holding (no Valsalva).';
      }
      if (hasBackPain) {
        note += ' Keep neutral spine; avoid loaded spinal flexion.';
      }

      plan.add(Workout(
        title: 'Day $d: ${_titleForFocus(focus)}',
        exercises: ex,
        durationMin: isBeginner ? 45 : 60,
        focus: focus,
        notes: note,
      ));
    }

    return plan;
  }

  static String _titleForFocus(String f) {
    switch (f) {
      case 'upper':
        return 'Upper Body + Cardio';
      case 'lower':
        return 'Lower Body + Cardio';
      default:
        return 'Full Body + Cardio';
    }
  }

  static List<String> _fullBodyBlock(bool beginner, bool back) {
    if (beginner) {
      return [
        if (!back) 'Goblet Squat 3x10 RPE 6',
        if (back) 'Leg Press (shallow range) 3x12 RPE 6',
        'Machine Chest Press 3x10 RPE 6',
        'Seated Row (cable) 3x10 RPE 6',
        'DB Shoulder Press (seated) 2x12 RPE 5–6',
        'Plank (knees if needed) 3x20–30s',
      ];
    } else {
      return [
        'Back Squat or Hack Squat 4x6–8 RPE 7',
        'Bench Press or Chest Press 4x6–8 RPE 7',
        'Barbell Row or Machine Row 4x6–8 RPE 7',
        'Romanian Deadlift 3x8–10 RPE 7',
        'Hanging Knee Raise 3x10–12',
      ];
    }
  }

  static List<String> _upperBlock(bool beginner) {
    if (beginner) {
      return [
        'Machine Chest Press 3x10 RPE 6',
        'Lat Pulldown 3x10 RPE 6',
        'Seated DB Shoulder Press 2x12 RPE 6',
        'Cable Row 3x10 RPE 6',
        'Triceps Pressdown 2x12 RPE 6',
        'DB Curl 2x12 RPE 6',
      ];
    } else {
      return [
        'Bench Press 4x6–8 RPE 7',
        'Weighted Pull-down / Pull-up 4x6–8 RPE 7',
        'Overhead Press 3x8–10 RPE 7',
        'Chest Supported Row 3x8–10 RPE 7',
        'Lateral Raise 3x12–15 RPE 7',
        'EZ-Bar Curl 3x10–12 RPE 7',
      ];
    }
  }

  static List<String> _lowerBlock(bool beginner, bool back) {
    if (beginner) {
      return [
        if (!back) 'Goblet Squat 3x10 RPE 6',
        if (back) 'Leg Press (shallow range) 3x12 RPE 6',
        'Leg Curl 3x12 RPE 6',
        'Leg Extension 3x12 RPE 6',
        'Calf Raise 3x12–15 RPE 6',
        'Bird-Dog 3x8/side',
      ];
    } else {
      return [
        'Back or Front Squat 4x6–8 RPE 7',
        'Romanian Deadlift 4x6–8 RPE 7',
        'Leg Press 3x10–12 RPE 7',
        'Seated Leg Curl 3x10–12 RPE 7',
        'Standing Calf Raise 3x12–15 RPE 7',
        'Weighted Plank 3x30–45s',
      ];
    }
  }
}
