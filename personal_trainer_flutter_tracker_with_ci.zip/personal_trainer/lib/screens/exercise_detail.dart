import 'package:flutter/material.dart';
import '../services/exercise_catalog.dart';
import '../models/exercise.dart';

class ExerciseDetail extends StatelessWidget {
  final String line; // original plan line
  const ExerciseDetail({super.key, required this.line});

  @override
  Widget build(BuildContext context) {
    final ex = ExerciseCatalog.resolve(line);
    return Scaffold(
      appBar: AppBar(title: Text(ex.name)),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: Center(
                child: Image.asset(ex.image, fit: BoxFit.contain),
              ),
            ),
            const SizedBox(height: 12),
            Text('How to do it', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 8),
            ...ex.tips.map((t) => Padding(
              padding: const EdgeInsets.symmetric(vertical: 4),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('• '),
                  Expanded(child: Text(t)),
                ],
              ),
            )),
            const SizedBox(height: 12),
            Text('Type: ${ex.type.toUpperCase()}'),
            const SizedBox(height: 8),
            Text('Note: Images are illustrative only. Use safe form and adjust load to your ability.',
              style: Theme.of(context).textTheme.bodySmall),
          ],
        ),
      ),
    );
  }
}
