import 'dart:async';
import 'package:flutter/material.dart';
import '../models/workout.dart';
import '../services/history.dart';
import '../services/exercise_catalog.dart';
import 'exercise_detail.dart';

class WorkoutSessionScreen extends StatefulWidget {
  final Workout workout;
  const WorkoutSessionScreen({super.key, required this.workout});

  @override
  State<WorkoutSessionScreen> createState() => _WorkoutSessionScreenState();
}

class _WorkoutSessionScreenState extends State<WorkoutSessionScreen> {
  int current = 0;
  int sets = 0;
  int reps = 0;
  bool running = false;
  int elapsed = 0; // session seconds
  int exerciseElapsed = 0; // current exercise seconds
  Timer? _ticker;
  DateTime started = DateTime.now();
  List<ExerciseLog> logs = [];

  @override
  void initState() {
    super.initState();
    _ticker = Timer.periodic(const Duration(seconds: 1), (t) {
      if (running) {
        setState(() {
          elapsed += 1;
          exerciseElapsed += 1;
        });
      }
    });
  }

  @override
  void dispose() {
    _ticker?.cancel();
    super.dispose();
  }

  void _nextExercise() {
    _commitCurrentLog();
    if (current < widget.workout.exercises.length - 1) {
      setState(() {
        current += 1;
        sets = 0;
        reps = 0;
        exerciseElapsed = 0;
      });
    } else {
      _finishSession();
    }
  }

  void _prevExercise() {
    if (current > 0) {
      _commitCurrentLog();
      setState(() {
        current -= 1;
        sets = 0;
        reps = 0;
        exerciseElapsed = 0;
      });
    }
  }

  void _commitCurrentLog() {
    final name = widget.workout.exercises[current];
    logs.add(ExerciseLog(name: name, sets: sets, reps: reps, durationSec: exerciseElapsed));
  }

  Future<void> _finishSession() async {
    _commitCurrentLog();
    final session = SessionLog(
      title: widget.workout.title,
      startedAt: started,
      totalDurationSec: elapsed,
      items: logs,
    );
    await HistoryStore.add(session);
    if (!mounted) return;
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Workout Saved'),
        content: Text('Total time: ${_fmtTime(elapsed)}'),
        actions: [
          TextButton(onPressed: () => Navigator.of(context).popUntil((r) => r.isFirst), child: const Text('Done'))
        ],
      ),
    );
  }

  String _fmtTime(int sec) {
    final m = (sec ~/ 60).toString().padLeft(2, '0');
    final s = (sec % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  @override
  Widget build(BuildContext context) {
    final line = widget.workout.exercises[current];
    final ex = ExerciseCatalog.resolve(line);

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.workout.title),
        actions: [
          IconButton(
            onPressed: _finishSession,
            icon: const Icon(Icons.check_circle),
            tooltip: 'Finish & Save',
          )
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text('Session: ${_fmtTime(elapsed)}', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 8),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(child: Text(ex.name, style: Theme.of(context).textTheme.titleLarge)),
                        Text(_fmtTime(exerciseElapsed)),
                      ],
                    ),
                    const SizedBox(height: 8),
                    AspectRatio(
                      aspectRatio: 16/9,
                      child: Image.asset(ex.image, fit: BoxFit.contain),
                    ),
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 8,
                      children: [
                        FilledButton.icon(
                          onPressed: () => setState(() => running = !running),
                          icon: Icon(running ? Icons.pause : Icons.play_arrow),
                          label: Text(running ? 'Pause' : 'Start'),
                        ),
                        OutlinedButton.icon(
                          onPressed: () => setState(() { exerciseElapsed = 0; }),
                          icon: const Icon(Icons.timer),
                          label: const Text('Reset timer'),
                        ),
                        OutlinedButton.icon(
                          onPressed: () {
                            Navigator.of(context).push(MaterialPageRoute(
                              builder: (_) => ExerciseDetail(line: line),
                            ));
                          },
                          icon: const Icon(Icons.info_outline),
                          label: const Text('How to do'),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Column(children: [
                          const Text('Sets'),
                          Row(children: [
                            IconButton(onPressed: () => setState(() { if (sets>0) sets--; }), icon: const Icon(Icons.remove_circle_outline)),
                            Text('$sets', style: Theme.of(context).textTheme.headlineSmall),
                            IconButton(onPressed: () => setState(() { sets++; }), icon: const Icon(Icons.add_circle_outline)),
                          ])
                        ]),
                        Column(children: [
                          const Text('Reps'),
                          Row(children: [
                            IconButton(onPressed: () => setState(() { if (reps>0) reps--; }), icon: const Icon(Icons.remove_circle_outline)),
                            Text('$reps', style: Theme.of(context).textTheme.headlineSmall),
                            IconButton(onPressed: () => setState(() { reps += 5; }), icon: const Icon(Icons.add_circle_outline)),
                          ])
                        ]),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            const Spacer(),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: _prevExercise,
                    icon: const Icon(Icons.chevron_left),
                    label: const Text('Previous'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: FilledButton.icon(
                    onPressed: _nextExercise,
                    icon: const Icon(Icons.chevron_right),
                    label: Text(current < widget.workout.exercises.length - 1 ? 'Next' : 'Finish'),
                  ),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}
