import 'package:flutter/material.dart';
import '../services/history.dart';

class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key});

  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  List<SessionLog> items = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final all = await HistoryStore.load();
    setState(() => items = all);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Workout History'),
        actions: [
          IconButton(
            onPressed: () async {
              await HistoryStore.clear();
              await _load();
            },
            icon: const Icon(Icons.delete_outline),
            tooltip: 'Clear history',
          )
        ],
      ),
      body: items.isEmpty
          ? const Center(child: Text('No history yet. Complete a workout to see it here.'))
          : ListView.separated(
              itemCount: items.length,
              separatorBuilder: (_, __) => const Divider(height: 1),
              itemBuilder: (context, i) {
                final s = items[i];
                final mins = (s.totalDurationSec / 60).floor();
                return ListTile(
                  title: Text(s.title),
                  subtitle: Text('${s.startedAt.toLocal()} • ${mins} min'),
                  onTap: () {
                    showModalBottomSheet(
                      context: context,
                      builder: (_) => Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(s.title, style: Theme.of(context).textTheme.titleMedium),
                            const SizedBox(height: 8),
                            ...s.items.map((e) => Padding(
                              padding: const EdgeInsets.symmetric(vertical: 4),
                              child: Text('• ${e.name}: ${e.sets} sets, ${e.reps} reps, ${e.durationSec}s'),
                            )),
                            const SizedBox(height: 12),
                          ],
                        ),
                      ),
                    );
                  },
                );
              },
            ),
    );
  }
}
