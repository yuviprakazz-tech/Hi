import 'package:flutter/material.dart';
import '../services/storage.dart';
import '../services/plan_engine.dart';
import '../models/workout.dart';
import '../models/user_profile.dart';
import 'plan_view.dart';
import 'history_screen.dart';
import 'onboarding.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  UserProfile? profile;
  List<Workout> plan = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final p = await Storage.loadProfile();
    final existing = await Storage.loadPlan();
    setState(() {
      profile = p;
      plan = existing;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (profile == null) return const OnboardingScreen();
    return Scaffold(
      appBar: AppBar(
        title: const Text('Your Trainer'),
        actions: [
          IconButton(
            onPressed: () {
              Navigator.of(context).push(MaterialPageRoute(
                builder: (_) => const HistoryScreen(),
              ));
            },
            icon: const Icon(Icons.history),
            tooltip: 'History',
          ),
          IconButton(
            onPressed: () async {
              final p = await Storage.loadProfile();
              if (p == null) return;
              final newPlan = PlanEngine.buildPlan(p);
              await Storage.savePlan(newPlan);
              setState(() => plan = newPlan);
              if (!mounted) return;
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Plan generated.'))
              );
            },
            icon: const Icon(Icons.auto_awesome),
            tooltip: 'Generate plan',
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Hello, ${profile!.name}', style: Theme.of(context).textTheme.headlineSmall),
            Text('BMI: ${profile!.bmi.toStringAsFixed(1)}  •  Days/Week: ${profile!.daysPerWeek}'),
            const SizedBox(height: 12),
            if (plan.isEmpty)
              const Text('No plan yet. Tap the sparkle icon to generate a plan.'),
            if (plan.isNotEmpty)
              Expanded(child: PlanView(plan: plan)),
          ],
        ),
      ),
    );
  }
}
