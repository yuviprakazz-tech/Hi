import 'package:flutter/material.dart';
import '../models/user_profile.dart';
import '../services/storage.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final _formKey = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _age = TextEditingController(text: '35');
  final _height = TextEditingController(text: '183');
  final _weight = TextEditingController(text: '138');
  String _sex = 'male';
  final Set<String> _conditions = {};
  int _experience = 0;
  int _days = 3;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Set up your profile')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              TextFormField(
                controller: _name,
                decoration: const InputDecoration(labelText: 'Name'),
                validator: (v) => v == null || v.isEmpty ? 'Required' : null,
              ),
              Row(children: [
                Expanded(
                  child: TextFormField(
                    controller: _age,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(labelText: 'Age (years)'),
                    validator: (v) => (v==null||v.isEmpty)?'Required':null,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: TextFormField(
                    controller: _height,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(labelText: 'Height (cm)'),
                    validator: (v) => (v==null||v.isEmpty)?'Required':null,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: TextFormField(
                    controller: _weight,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(labelText: 'Weight (kg)'),
                    validator: (v) => (v==null||v.isEmpty)?'Required':null,
                  ),
                ),
              ]),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                value: _sex,
                items: const [
                  DropdownMenuItem(value: 'male', child: Text('Male')),
                  DropdownMenuItem(value: 'female', child: Text('Female')),
                  DropdownMenuItem(value: 'other', child: Text('Other')),
                ],
                onChanged: (v) => setState(() => _sex = v ?? 'other'),
                decoration: const InputDecoration(labelText: 'Sex'),
              ),
              const SizedBox(height: 8),
              const Text('Health conditions (optional):'),
              Wrap(
                spacing: 8,
                children: [
                  _chip('hypertension'),
                  _chip('diabetes'),
                  _chip('back_pain'),
                  _chip('asthma'),
                ],
              ),
              const SizedBox(height: 8),
              DropdownButtonFormField<int>(
                value: _experience,
                items: const [
                  DropdownMenuItem(value: 0, child: Text('Beginner')),
                  DropdownMenuItem(value: 1, child: Text('Intermediate')),
                  DropdownMenuItem(value: 2, child: Text('Advanced')),
                ],
                onChanged: (v) => setState(() => _experience = v ?? 0),
                decoration: const InputDecoration(labelText: 'Experience level'),
              ),
              const SizedBox(height: 8),
              Slider(
                value: _days.toDouble(),
                min: 2, max: 6, divisions: 4,
                label: '$_days days/week',
                onChanged: (v) => setState(() => _days = v.round()),
              ),
              const SizedBox(height: 12),
              Text(
                'Disclaimer: This app uses simple rules and is not medical advice. '
                'Please consult your doctor before starting any new exercise plan, especially if you have health conditions.',
                style: Theme.of(context).textTheme.bodySmall,
              ),
              const SizedBox(height: 12),
              FilledButton(
                onPressed: () async {
                  if (_formKey.currentState!.validate()) {
                    final p = UserProfile(
                      name: _name.text.trim(),
                      age: int.tryParse(_age.text.trim()) ?? 0,
                      heightCm: double.tryParse(_height.text.trim()) ?? 0,
                      weightKg: double.tryParse(_weight.text.trim()) ?? 0,
                      sex: _sex,
                      conditions: _conditions.toList(),
                      experienceLevel: _experience,
                      daysPerWeek: _days,
                    );
                    await Storage.saveProfile(p);
                    if (!mounted) return;
                    Navigator.of(context).pushReplacementNamed('/');
                  }
                },
                child: const Text('Save & Continue'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _chip(String label) {
    final sel = _conditions.contains(label);
    return FilterChip(
      label: Text(label),
      selected: sel,
      onSelected: (v) => setState(() {
        if (v) { _conditions.add(label); } else { _conditions.remove(label); }
      }),
    );
  }
}
