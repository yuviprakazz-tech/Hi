import 'package:flutter/material.dart';
import '../models/workout.dart';
import 'workout_session.dart';
import 'exercise_detail.dart';
import '../services/exercise_catalog.dart';

class PlanView extends StatelessWidget {
  final List<Workout> plan;
  const PlanView({super.key, required this.plan});

  @override
  Widget build(BuildContext context) {
    return ListView.separated(
      itemCount: plan.length,
      separatorBuilder: (_, __) => const SizedBox(height: 12),
      itemBuilder: (context, i) {
        final w = plan[i];
        return Card(
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(w.title, style: Theme.of(context).textTheme.titleMedium),
                    Text('${w.durationMin} min'),
                  ],
                ),
                const SizedBox(height: 8),
                ...w.exercises.map((e) {
                  final ex = ExerciseCatalog.resolve(e);
                  return Padding(
                    padding: const EdgeInsets.symmetric(vertical: 4),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('• '),
                        Expanded(child: Text(e)),
                        IconButton(
                          icon: const Icon(Icons.image_search),
                          tooltip: 'How to do',
                          onPressed: () {
                            Navigator.of(context).push(MaterialPageRoute(
                              builder: (_) => ExerciseDetail(line: e),
                            ));
                          },
                        )
                      ],
                    ),
                  );
                }),
                const SizedBox(height: 8),
                Text(w.notes, style: Theme.of(context).textTheme.bodySmall),
                const SizedBox(height: 8),
                Align(
                  alignment: Alignment.centerRight,
                  child: FilledButton.icon(
                    onPressed: () {
                      Navigator.of(context).push(MaterialPageRoute(
                        builder: (_) => WorkoutSessionScreen(workout: w),
                      ));
                    },
                    icon: const Icon(Icons.play_circle),
                    label: const Text('Start workout'),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
