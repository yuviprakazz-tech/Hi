import 'package:flutter/material.dart';
import 'screens/onboarding.dart';
import 'screens/home.dart';
import 'services/storage.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final profile = await Storage.loadProfile();
  runApp(PersonalTrainerApp(hasProfile: profile != null));
}

class PersonalTrainerApp extends StatelessWidget {
  final bool hasProfile;
  const PersonalTrainerApp({super.key, required this.hasProfile});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Personal Trainer',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.teal,
      ),
      home: hasProfile ? const HomeScreen() : const OnboardingScreen(),
    );
  }
}
