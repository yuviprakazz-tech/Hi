class Exercise {
  final String key; // unique id
  final String name;
  final String image; // asset path
  final List<String> tips; // how-to
  final String type; // 'strength' | 'cardio' | 'stretch'

  const Exercise({
    required this.key,
    required this.name,
    required this.image,
    required this.tips,
    required this.type,
  });
}
