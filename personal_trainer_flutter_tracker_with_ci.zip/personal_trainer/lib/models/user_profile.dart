class UserProfile {
  final String name;
  final int age;
  final double heightCm;
  final double weightKg;
  final String sex; // 'male' | 'female' | 'other'
  final List<String> conditions; // e.g., ['hypertension', 'diabetes', 'back_pain']
  final int experienceLevel; // 0 beginner, 1 intermediate, 2 advanced
  final int daysPerWeek; // planned workout frequency

  const UserProfile({
    required this.name,
    required this.age,
    required this.heightCm,
    required this.weightKg,
    required this.sex,
    required this.conditions,
    required this.experienceLevel,
    required this.daysPerWeek,
  });

  double get bmi => weightKg / ((heightCm / 100) * (heightCm / 100));

  Map<String, dynamic> toJson() => {
        'name': name,
        'age': age,
        'heightCm': heightCm,
        'weightKg': weightKg,
        'sex': sex,
        'conditions': conditions,
        'experienceLevel': experienceLevel,
        'daysPerWeek': daysPerWeek,
      };

  factory UserProfile.fromJson(Map<String, dynamic> j) => UserProfile(
        name: j['name'] ?? '',
        age: j['age'] ?? 0,
        heightCm: (j['heightCm'] ?? 0).toDouble(),
        weightKg: (j['weightKg'] ?? 0).toDouble(),
        sex: j['sex'] ?? 'other',
        conditions: (j['conditions'] as List?)?.cast<String>() ?? <String>[],
        experienceLevel: j['experienceLevel'] ?? 0,
        daysPerWeek: j['daysPerWeek'] ?? 3,
      );
}
