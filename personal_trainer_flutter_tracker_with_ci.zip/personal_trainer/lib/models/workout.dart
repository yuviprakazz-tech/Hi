class Workout {
  final String title;
  final List<String> exercises; // each is a line like "Leg Press 3x10 RPE 6"
  final int durationMin;
  final String focus; // e.g., 'full_body', 'upper', 'lower', 'cardio'
  final String notes;

  const Workout({
    required this.title,
    required this.exercises,
    required this.durationMin,
    required this.focus,
    required this.notes,
  });

  Map<String, dynamic> toJson() => {
        'title': title,
        'exercises': exercises,
        'durationMin': durationMin,
        'focus': focus,
        'notes': notes,
      };

  factory Workout.fromJson(Map<String, dynamic> j) => Workout(
        title: j['title'] ?? '',
        exercises: (j['exercises'] as List?)?.cast<String>() ?? <String>[],
        durationMin: j['durationMin'] ?? 45,
        focus: j['focus'] ?? 'full_body',
        notes: j['notes'] ?? '',
      );
}
