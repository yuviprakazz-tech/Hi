# Personal Trainer (Offline, Rules-based) — Flutter

> Private, on-device fitness planner that generates a weekly gym plan from your profile.  
> **Not medical advice.** Please consult a physician before starting a new program.

## What you get
- Onboarding to capture profile (age, height, weight, sex, conditions, experience, days/week)
- Local storage with `shared_preferences` (no cloud, data stays on device)
- Simple rules engine that adapts volume/exercises for BMI and conditions (hypertension, diabetes, back pain)
- Plan viewer card list
- Clean Material 3 UI

## How to run
1. [Install Flutter](https://docs.flutter.dev/get-started/install) and set up Android Studio or Xcode.
2. Unzip this folder, open it in VS Code/Android Studio.
3. Run:
   ```bash
   flutter pub get
   flutter run
   ```
4. To make a release APK (Android):
   ```bash
   flutter build apk --release
   ```
   The APK appears under `build/app/outputs/flutter-apk/`.

## Customize the plan engine
Open `lib/services/plan_engine.dart` and tweak exercises, set/rep schemes, and rules.

## Roadmap ideas
- Workout logger & history
- Push reminders (local notifications)
- Heart-rate/RPE capture
- Nutrition targets and hydration reminders
- Export/share plan as PDF

---

**Disclaimer**: This app provides general fitness guidance and is not a substitute for professional medical advice.
